import styles from './Rodape.module.css';

function Rodape() {
  return (
    <footer className={styles.rodape}>
      <p>Guia Liverpool para Intercambistas - 2026</p>
      <p>Feito por Isac Lopes Rego - Laboratório de Desenvolvimento Web</p>
    </footer>
  );
}

export default Rodape;
