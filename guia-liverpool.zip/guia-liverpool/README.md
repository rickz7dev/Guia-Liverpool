# Guia Liverpool

Projeto da disciplina Laboratório de Desenvolvimento Web.

Site SPA feito com React sobre os principais lugares de Liverpool e dicas para intercambistas.

## Como rodar

```
npm install
npm start
```

Depois abrir http://localhost:3000
